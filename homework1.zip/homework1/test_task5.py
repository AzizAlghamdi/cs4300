import task5

def test_get_first_three_books():
	assert len(task5.get_first_three_books()) == 3

