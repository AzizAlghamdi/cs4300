def get_data_types():
	return {
	"integer": 10,
	"float": 10.5,
	"string": "Python",
	"boolean": True
	}
