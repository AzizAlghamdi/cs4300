import task1

def test_say_hello():

	assert task1.say_hello() == "Hello World!"
