import task6
def test_count_words():
	assert task6.count_words("task6_read_me.txt") == 8
