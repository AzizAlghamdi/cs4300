import task7

def test_fetch_google():
	assert task7.fetch_google() == 200
