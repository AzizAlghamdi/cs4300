books = [
	{"title": "Book A", "author": "Author A"},
	{"title": "Book B", "author": "Author B"},
	{"title": "Book C", "author": "Author C"},
	{"title": "Book D", "author": "Author D"}
]
students = {
	"Alice": 101,
	"Bob": 102,
	"Sam": 103
}

def get_first_three_books():
	return books[:3]
